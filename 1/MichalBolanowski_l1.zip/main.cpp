#include <iostream>
#include "Renderer.h"
using namespace std;

int main()
{
    char ARGB[4] = {0,(char)0xFF,0,(char)0xFF};
    short SIZE[2] = {100, 800};

    Renderer render(ARGB, SIZE);
    render.Save();

    return 0;
}
